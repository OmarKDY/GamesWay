=== CTL Puzzle Deluxe ===
Tags: board game, brain game, find image, html5 board game, image, memory, slide, slide 15, tile, tiles
Requires at least: 4.3
Tested up to: 4.3

Add Puzzle Deluxe to CTL Arcade plugin

== Description ==
Add Puzzle Deluxe to CTL Arcade plugin