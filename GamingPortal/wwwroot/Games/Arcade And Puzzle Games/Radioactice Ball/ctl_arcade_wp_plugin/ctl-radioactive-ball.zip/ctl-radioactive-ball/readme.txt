=== CTL Radioactive Ball ===
Tags: arcade game, pixel game, pang, Pomping World, Buster Bros, action game, super pang, Cannon Ball, bubble buster, action game, android, ios, classic game, pixel art, retro game

Requires at least: 4.3
Tested up to: 4.3

Add Radioactive Ball to CTL Arcade plugin

== Description ==
Add Radioactive Ball to CTL Arcade plugin


	