=== CTL Waffle ===
Tags: anagram, drag, game, html5, languages, letters, mobile, puzzle, ruzzle, skill, word, word game, multilanguage, kid game, school game, educational
Requires at least: 4.3
Tested up to: 4.3

Add Waffle to CTL Arcade plugin

== Description ==
Add Waffle to CTL Arcade plugin


	