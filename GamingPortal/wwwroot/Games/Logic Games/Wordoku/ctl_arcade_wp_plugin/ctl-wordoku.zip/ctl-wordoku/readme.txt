=== CTL Wordoku ===
Tags: board game, brain game, brain teasers, crossword, grid, word game, html5 sudoku, math game, letter, skill game, sudoku
Requires at least: 4.3
Tested up to: 4.3

Add Wordoku to CTL Arcade plugin

== Description ==
Add Wordoku to CTL Arcade plugin