=== CTL Tap The Tile C2 ===
Tags: tap the black tile, skill game, tap game, tapping game, logic game, survival game, endless game, piano tile, don't tap the white tile, don't touch, don't tap, capx, admob, construct 2, black and white
Requires at least: 9.16
Tested up to: 9.16

Add Tap The Tile C2 to CTL Arcade plugin

== Description ==
Add Tap The Tile C2 to CTL Arcade plugin


	