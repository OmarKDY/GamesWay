=== CTL Guess Who ===
Tags: arcade, character, guess who, mobile, question, quiz, quiz game, board game, html5 quiz, indovina chi,Wer ist es,Quién es quién,Qui est-ce, classic game
Requires at least: 4.3
Tested up to: 4.3

Add Guess Who to CTL Arcade plugin

== Description ==
Add Guess Who to CTL Arcade plugin


	