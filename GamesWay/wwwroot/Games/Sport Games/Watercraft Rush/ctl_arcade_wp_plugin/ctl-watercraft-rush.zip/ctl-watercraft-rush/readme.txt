=== CTL WaterCraft Rush ===
Tags: 	race, racing game, speed, water game, watercraft, adventure, extreme sport, booster, competition, driving game, motors, out run, skill game, survival game, car speed
Requires at least: 4.3
Tested up to: 4.3

Add WaterCraft Rush to CTL Arcade plugin

== Description ==
Add WaterCraft Rush to CTL Arcade plugin