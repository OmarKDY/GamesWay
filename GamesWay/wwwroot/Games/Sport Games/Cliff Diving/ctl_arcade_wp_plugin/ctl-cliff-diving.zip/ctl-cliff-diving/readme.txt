=== CTL Cliff Diving ===
Tags: skill game, summer game, jump, dive, diving, sport game, extreme sport game, boy game, adventure, cliff diving, flip, flip diving, flip master, Pull off, Frontflips, swimming game
Requires at least: 4.3
Tested up to: 4.3

Add Cliff Diving to CTL Arcade plugin

== Description ==
Add Cliff Diving to CTL Arcade plugin


	