=== CTL Rugby Rush ===
Tags: american football,american, run, running, running game, rush, touchdown, football, sport, sport game, 3d,baseball,skill,rugby,super bowl,3d game
Requires at least: 4.3
Tested up to: 4.3

Add Rugby Rush to CTL Arcade plugin

== Description ==
Add Rugby Rush to CTL Arcade plugin


	