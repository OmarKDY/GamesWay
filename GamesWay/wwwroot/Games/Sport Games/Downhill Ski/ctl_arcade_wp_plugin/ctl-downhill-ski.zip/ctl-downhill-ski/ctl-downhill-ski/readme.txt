=== CTL Downhill Ski ===
Tags: olympic, ski, skier, sport, sport game, snow, seasonal, 3D, 3D game, classic, olympic game, run, running, rush, simulation
Requires at least: 4.3
Tested up to: 4.3

Add Downhill Ski to CTL Arcade plugin

== Description ==
Add Downhill Ski to CTL Arcade plugin


	