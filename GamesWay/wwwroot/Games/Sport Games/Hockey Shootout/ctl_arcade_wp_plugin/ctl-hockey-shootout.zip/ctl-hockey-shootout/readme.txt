=== CTL Hockey Shootout ===
Tags: sport game, action game, winter game, skill game, penalty kicks, ice hockey, winter olympics game, goal, goalkeeper, penalty game, kick, penalties, defend, winter game, arcade game
Requires at least: 4.3
Tested up to: 4.3

Add Hockey Shootout to CTL Arcade plugin

== Description ==
Add Hockey Shootout to CTL Arcade plugin


	