=== CTL Rugby Kicks ===
Tags: rugby games, football, rugby, 3D, sport game, sports game, sport games,  freekick, skill game, penalty, penalties, goal, tackle, all blacks , kick
Requires at least: 4.3
Tested up to: 4.3

Add Rugby Kicks to CTL Arcade plugin

== Description ==
Add Rugby Kicks to CTL Arcade plugin


	