=== CTL Darts Pro ===
Tags: darts, classic game, retro, arcade, sport, action, olympic, skill,sport game , classic, dart , target, html5 dart, darts game , skill game
Requires at least: 4.3
Tested up to: 4.3

Add Darts Pro to CTL Arcade plugin

== Description ==
Add Darts Pro to CTL Arcade plugin


	