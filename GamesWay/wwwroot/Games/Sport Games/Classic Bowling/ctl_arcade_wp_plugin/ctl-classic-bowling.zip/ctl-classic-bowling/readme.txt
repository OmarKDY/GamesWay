=== CTL Classic Bowling ===
Tags: bowling, strike, spare, sport, sport game, bowls, skill game, pin, ten-pin bowling, gutterball, bowler, target bowling, roll out, power stroker, split
Requires at least: 4.3
Tested up to: 4.3

Add Classic Bowling to CTL Arcade plugin

== Description ==
Add Classic Bowling to CTL Arcade plugin


	