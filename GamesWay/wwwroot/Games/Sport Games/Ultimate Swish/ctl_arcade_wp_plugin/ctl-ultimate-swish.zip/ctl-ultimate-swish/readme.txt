=== CTL Ultimate Swish ===
Tags: 3 points, basket, basketball, physic, physics, shootout, shot, sport, sport game, swish, three points, shoot-out, skill game, tap game, one button game
Requires at least: 4.3
Tested up to: 4.3

Add Ultimate Swish to CTL Arcade plugin

== Description ==
Add Ultimate Swish to CTL Arcade plugin


	