=== CTL Classic Backgammon ===
Tags: board game, chess, checkers, classic game, logic game, skill game, table game, multiplayer, strategy game, two player, race game, dice game, tactic game, nard game, wordpress
Requires at least: 4.3
Tested up to: 4.3

Add Classic Backgammon to CTL Arcade plugin

== Description ==
Add Classic Backgammon to CTL Arcade plugin


	