var TEXT_PRELOADER_CONTINUE = "START";
var TEXT_GAMEOVER  = "%s WINS";
var TEXT_DRAW      = "DRAW";
var TEXT_MOVES      = "MOVES";
var TEXT_THINKING   = "THINKING";
var TEXT_ARE_SURE = "ARE YOU SURE?";

var TEXT_MODE      = "CHOOSE GAME MODE";

var TEXT_BLACK     = "BLACK";
var TEXT_WHITE     = "WHITE";

var TEXT_JUMP      = "MANDATORY JUMP!";
var TEXT_MOVES_AVAIL = "(%s NO MOVES AVAILABLE)";

var TEXT_CREDITS_DEVELOPED = "DEVELOPED BY";

var TEXT_SHARE_IMAGE = "200x200.jpg";
var TEXT_SHARE_TITLE = "Congratulations!";
var TEXT_SHARE_MSG1 = "You collected <strong>";
var TEXT_SHARE_MSG2 = " points</strong>!<br><br>Share your score with your friends!";
var TEXT_SHARE_SHARE1 = "My score is ";
var TEXT_SHARE_SHARE2 = " points! Can you do better?";

