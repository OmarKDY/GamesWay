=== CTL Master Checker ===
Tags: 	board game, checkers, chess, classic game, dama, draughts, html5 board game, html5 checkers, html5 classic game, html5 draughts, multiplayer, multiplayer checkers, multiplayer draughts, strategy game, two player
Requires at least: 4.3
Tested up to: 4.3

Add Master Checker to CTL Arcade plugin

== Description ==
Add Master Checker to CTL Arcade plugin