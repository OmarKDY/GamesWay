=== CTL Master Chess ===
Tags: 		board game, checkers, chess, classic game, dama, draughts, html5 board game, html5 chess, html5 classic game, html5 draughts, multiplayer, multiplayer chess, multiplayer draughts, strategy game, two player
Requires at least: 4.3
Tested up to: 4.3

Add Gear Madness to CTL Arcade plugin

== Description ==
Add Gear Madness to CTL Arcade plugin