var TEXT_PRELOADER_CONTINUE = "START";
var TEXT_DRAW      = "(draw)";
var TEXT_WINS      = "(%s wins)";
var TEXT_CHECKMATE = "CHECKMATE!";
var TEXT_STALEMATE = "STALEMATE!"
var TEXT_ARE_SURE = "ARE YOU SURE?";

var TEXT_MODE      = "CHOOSE GAME MODE";

var TEXT_BLACK     = "black";
var TEXT_WHITE     = "white";

var TEXT_PROMOTION = "SELECT THE PIECE YOU WANT TO PROMOTE YOUR PAWN INTO";
var TEXT_CHECK = "CHECK!";

var TEXT_CREDITS_DEVELOPED = "DEVELOPED BY";

var TEXT_SHARE_IMAGE = "200x200.jpg";
var TEXT_SHARE_TITLE = "Congratulations!";
var TEXT_SHARE_MSG1 = "You collected <strong>";
var TEXT_SHARE_MSG2 = " points</strong>!<br><br>Share your score with your friends!";
var TEXT_SHARE_SHARE1 = "My score is ";
var TEXT_SHARE_SHARE2 = " points! Can you do better?";

