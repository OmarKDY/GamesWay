=== CTL Reversi ===
Tags: 	board game, checkers, classic game, draughts, html5 board game, html5 classic game, html5 othello, html5 reversi, othello, reversi, strategy game, two player
Requires at least: 4.3
Tested up to: 4.3

Add Reversi to CTL Arcade plugin

== Description ==
Add Reversi to CTL Arcade plugin