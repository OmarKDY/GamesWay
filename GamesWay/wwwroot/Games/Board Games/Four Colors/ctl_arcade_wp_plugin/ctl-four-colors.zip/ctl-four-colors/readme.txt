=== CTL Four Colors ===
Tags: uno, card game, solitaire, uno game, solitaire game, table game, board game, freecell, strategy game, skill game, html5 Uno, html5 card game, multiplayer game, wordpress game, educational game
Requires at least: 4.3
Tested up to: 4.3

Add Four Colors to CTL Arcade plugin

== Description ==
Add Four Colors to CTL Arcade plugin


	