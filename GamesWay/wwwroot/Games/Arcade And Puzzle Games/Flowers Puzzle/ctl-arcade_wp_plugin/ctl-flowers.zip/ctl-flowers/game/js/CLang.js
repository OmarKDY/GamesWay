var TEXT_SELECT_DIFFICULTY = "SELECT DIFFICULTY";
var TEXT_SELECT_LEVEL     = "SELECT LEVEL";
var TEXT_LEVEL            = "LEVEL: %s";
var TEXT_LEVEL_COMPLETED  = "LEVEL COMPLETED!";
var TEXT_WIN             = "CONGRATULATIONS!\nYOU HAVE COMPLETED ALL THE LEVELS!";
var TEXT_FILL_CELLS       = "YOU HAVE TO FILL ALL THE CELLS";
var TEXT_HELP             = "CONNECT MATCHING FLOWERS AND COVER THE ENTIRE BOARD TO SOLVE EACH LEVEL";
var TEXT_HELP_TITLE       = "HOW TO PLAY";
var TEXT_SCORE            = "YOUR SCORE IS: %s";
var TEXT_MOVES            = "MOVES: %s/%s";
var TEXT_DEVELOPED        = "DEVELOPED BY";
var TEXT_DELETE           = "THIS WILL DELETE ALL YOUR PROGRESS, ARE YOU SURE?";        
var TEXT_IOS_PRIVATE      = 'Your web browser does not support storing settings locally. In Safari, the most common cause of this is using "Private Browsing Mode". Some info may not save or some features may not work properly';
         
         
var TEXT_SHARE_IMAGE = "200x200.jpg";
var TEXT_SHARE_TITLE = "Congratulations!";
var TEXT_SHARE_MSG1 = "You collected <strong>";
var TEXT_SHARE_MSG2 = " points</strong>!<br><br>Share your score with your friends!";
var TEXT_SHARE_SHARE1 = "My score is ";
var TEXT_SHARE_SHARE2 = " points! Can you do better?";