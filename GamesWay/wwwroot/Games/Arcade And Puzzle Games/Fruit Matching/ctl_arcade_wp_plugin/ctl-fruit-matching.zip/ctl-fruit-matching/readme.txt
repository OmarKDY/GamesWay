=== CTL Fruit Matching ===
Tags: arcade game, bejeweled, candy, candy crush, color match, fruit, fruit game, match 3, match-3, matching, matching game, puzzle game, Seven Senses matching
Requires at least: 4.3
Tested up to: 4.3

Add Fruit Matching to CTL Arcade plugin

== Description ==
Add Fruit Matching to CTL Arcade plugin


	