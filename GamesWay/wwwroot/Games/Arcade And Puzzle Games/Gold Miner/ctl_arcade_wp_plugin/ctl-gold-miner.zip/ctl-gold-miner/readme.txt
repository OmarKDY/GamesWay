=== CTL Gold Miner ===
Tags:  arcade, classic game, digger, game, gold miner, html5, mobile, puzzle, puzzle game, arcade game
Requires at least: 4.3
Tested up to: 4.3

Add Gold Miner to CTL Arcade plugin

== Description ==
Add Gold Miner to CTL Arcade plugin


	