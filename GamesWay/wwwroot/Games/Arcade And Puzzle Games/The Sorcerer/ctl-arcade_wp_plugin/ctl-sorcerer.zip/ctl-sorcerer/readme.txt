=== CTL The Sorcerer ===
Tags: android game, canvas, color match, html5, iOS GAME, match three, match-3, matching, matching game, mobile, mobile game, puzzle, puzzle game, Zuma, zuma balls

Requires at least: 4.3
Tested up to: 4.3

Add The Sorcerer to CTL Arcade plugin

== Description ==
Add The Sorcerer to CTL Arcade plugin


	