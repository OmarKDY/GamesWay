=== CTL Funny Faces ===
Tags: bejeweled, candy crush, canvas, color match, html 5, html5 matching, match 3, match-3, matching, matching game, puzzle game, Seven Senses
Requires at least: 4.3
Tested up to: 4.3

Add Funny Faces to CTL Arcade plugin

== Description ==
Add Funny Faces to CTL Arcade plugin


	