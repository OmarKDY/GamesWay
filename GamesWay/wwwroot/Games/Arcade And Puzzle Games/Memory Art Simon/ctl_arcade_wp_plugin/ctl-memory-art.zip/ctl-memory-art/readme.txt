=== CTL Memory Art ===
Tags: memory, mobile, puzzle, puzzle game, simon, memory game, mind game, quiz game, simon game, speed game, educational game, kid game, music game
Requires at least: 4.3
Tested up to: 4.3

Add Memory Art to CTL Arcade plugin

== Description ==
Add Memory Art to CTL Arcade plugin


	