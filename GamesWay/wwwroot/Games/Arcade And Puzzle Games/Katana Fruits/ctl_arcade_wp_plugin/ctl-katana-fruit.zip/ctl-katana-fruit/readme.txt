=== CTL Katana Fruit ===
Tags: action, arcade, coffee break, cut, fruit, fruit ninja, html5, ninja, physics, samurai, slice mobile, touch, arcade game, mobile game, fruit game
Requires at least: 4.3
Tested up to: 4.3

Add Katana Fruit to CTL Arcade plugin

== Description ==
Add Katana Fruit to CTL Arcade plugin


	