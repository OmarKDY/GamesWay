=== CTL Zombie Invasion ===
Tags: 		base defence, blood, canvas, gore, gun, horror, shooter, shot, survival, Tap Game, walking dead, zombie, zombies,zombie game
Requires at least: 4.3
Tested up to: 4.3

Add Zombie Invasion to CTL Arcade plugin

== Description ==
Add Zombie Invasion to CTL Arcade plugin