=== CTL Wothan The Barbarian ===
Tags: Rapid roll, fall game, falling game, rolling game, jumping game, roll jump, classic game, action game, survival game,  escaping game, wordpress, facebook, twitter, doodle jump, mega jump, running game
Requires at least: 4.3
Tested up to: 4.3

Add Wothan The Barbarian to CTL Arcade plugin

== Description ==
Add Wothan The Barbarian to CTL Arcade plugin


	