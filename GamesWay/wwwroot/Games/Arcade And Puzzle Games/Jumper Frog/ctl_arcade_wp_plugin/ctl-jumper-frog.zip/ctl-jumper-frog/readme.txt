=== CTL Jumper Frog ===
Tags: 	arcade, arcade game, classic game, frogger, html5 arcade game, html5 retro game, jump, retro game,skill game, kids game, funny game
Requires at least: 4.3
Tested up to: 4.3

Add Jumper Frog to CTL Arcade plugin

== Description ==
Add Jumper Frog to CTL Arcade plugin