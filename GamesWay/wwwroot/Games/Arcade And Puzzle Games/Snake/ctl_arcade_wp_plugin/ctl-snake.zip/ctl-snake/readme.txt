=== CTL Snake ===
Tags: android game, Animals Game, arcade game, browser game, classic, classic game, fruit, iOS GAME, level, mobile game, nokia 3310, nokia game, puzzle, retro game, snake
 Requires at least: 4.3
Tested up to: 4.3

Add Snake to CTL Arcade plugin

== Description ==
Add Snake to CTL Arcade plugin


	