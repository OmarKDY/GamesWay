=== CTL Galactic War ===
Tags: arcade, bullet, mobile, retro, shooter, space, spaceship, space game, arcade game, retro game, classic game, asteroids, shot, shoot, shooting game
Requires at least: 4.3
Tested up to: 4.3

Add Galactic War to CTL Arcade plugin

== Description ==
Add Galactic War to CTL Arcade plugin


	