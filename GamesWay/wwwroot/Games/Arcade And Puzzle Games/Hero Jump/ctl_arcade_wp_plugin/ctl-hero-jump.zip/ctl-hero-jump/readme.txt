=== CTL Hero Jump ===
Tags: arcade game, endless game, classic game, action game, doodle jump, jumping game, HTML5 jump game, jump game, mobile jump game, survival game, wordpress, leaderboard, facebook, twitter, share score
Requires at least: 4.3
Tested up to: 4.3

Add Hero Jump to CTL Arcade plugin

== Description ==
Add Hero Jump to CTL Arcade plugin


	