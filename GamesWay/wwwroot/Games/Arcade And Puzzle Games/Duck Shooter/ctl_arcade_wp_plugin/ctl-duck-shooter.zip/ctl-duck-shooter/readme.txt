=== CTL Duck Shooter ===
Tags: 		arcade, classic game, duck, duck shooter, html5 game, mobile, shooter, shot, survival
Requires at least: 4.3
Tested up to: 4.3

Add Duck Shooter to CTL Arcade plugin

== Description ==
Add Duck Shooter to CTL Arcade plugin