=== CTL Sweety Memory ===
Tags: brain game, candy, card, cards, game, HTML5 memory, memory, memory game, puzzle, skill, strategy, kid game, children game, skill game
Requires at least: 4.3
Tested up to: 4.3

Add Sweety Memory to CTL Arcade plugin

== Description ==
Add Sweety Memory to CTL Arcade plugin


	