=== CTL Maze ===
Tags: maze, labyrinth, brain game, skill game, logic game, strategy, classic game, brain teaser, quiz game, board game, deduction game, logics, puzzle, skill, html5
Requires at least: 4.3
Tested up to: 4.3

Add Maze to CTL Arcade plugin

== Description ==
Add Maze to CTL Arcade plugin


	