=== CTL Mastermind ===
Tags: brain game, skill game, matching game, logic game, mastermind, guessing game, strategy, classic game, brain teaser, quiz game, board game, code-breaking game, code breaking game, deduction game, logics
Requires at least: 4.3
Tested up to: 4.3

Add Mastermind to CTL Arcade plugin

== Description ==
Add Mastermind to CTL Arcade plugin


	