=== CTL 4 Images And 1 Word ===
Tags: 4 pics 1 word, 4 pictures 1 word, brain game, four pics one, four pictures one word, guess, knowledge game, logic game, multilingual, multilingual game, pictures, quiz game, skills game, word game, words
Requires at least: 4.3
Tested up to: 4.3

Add 4 Images And 1 Word to CTL Arcade plugin

== Description ==
Add 4 Images And 1 Word to CTL Arcade plugin


	