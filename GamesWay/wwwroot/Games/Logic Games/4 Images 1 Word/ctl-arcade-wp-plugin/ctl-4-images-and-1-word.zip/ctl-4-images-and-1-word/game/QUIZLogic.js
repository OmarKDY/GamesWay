var s_aQuestions = [
{
"img" : 
[{"file": ["imghome1", "imghome2", "imghome3", "imghome4"],
"copyright" : ["immobiliarecasaserena.com", "FOR TEST ONLY", "FOR TEST ONLY","FOR TEST ONLY"]}],
"answer" : [
"HOME", "MAISON", "CASA", "CASA", "HAUS", "CASA"
]
},{
"img" : 
[{"file": ["imgcat1", "imgcat2", "imgcat3", "imgcat4"],
"copyright" : ["FOR TEST ONLY", "FOR TEST ONLY", "FOR TEST ONLY","FOR TEST ONLY"]}],
"answer" : [
"CAT","CHAT","GATTO","GATO","KATZE","GATO"
]
},{
"img" : 
[{"file": ["imghappy1","imghappy2","imghappy3","imghappy4"],
"copyright" : ["FOR TEST ONLY", "FOR TEST ONLY", "FOR TEST ONLY","FOR TEST ONLY"]}],
"answer" : [
"HAPPY","HEUREIX","FELICE","CONTENTO","FROH","FELIZ"
]
},{
"img" : 
[{"file": ["imgdrink1","imgdrink2","imgdrink3","imgdrink4"],
"copyright" : ["FOR TEST ONLY", "FOR TEST ONLY", "FOR TEST ONLY","FOR TEST ONLY"]}],
"answer" : [
"DRINK","BOISSON","BIBITA","BEBER","TRINKEN","BEBE"
]
},{
"img" : 
[{"file": ["imgminute1","imgminute2","imgminute3","imgminute4"],
"copyright" : ["guanellani.org", "www.livescience.com", "fotografiafacile.wordpress.com","wikipedia.org"]}],
"answer" : [
"MINUTE","MINUTE","MINUTO","MINUTO","MINUTE","MINUTO"
]
},{
"img" : 
[{"file": ["imgsound1","imgsound2","imgsound3","imgsound4"],
"copyright" : ["mytholipedia.com", "www.livescience.com", "verytech.smartworld.it","joho.org"]}],
"answer" : [
"SOUND","BRUIT","SUONO","SONIDO","KLANG","SOM"
]
},{
"img" : 
[{"file": ["imgcacao1","imgcacao2","imgcacao3","imgcacao4"],
"copyright" : ["FOR TEST ONLY", "FOR TEST ONLY", "FOR TEST ONLY","FOR TEST ONLY"]}],
"answer" : [
"COCOA","CACAO","CACAO","CACAO","KAKAO","CACAU"
]
},{
"img" : 
[{"file": ["imgfull1","imgfull2","imgfull3","imgfull4"],
"copyright" : ["FOR TEST ONLY", "FOR TEST ONLY", "123RF.com","joho.org"]}],
"answer" : [
"FULL","PLEIN","PIENO","LLENO","VOLL","CHEIO"
]
},{
"img" : 
[{"file": ["imgcold1","imgcold2","imgcold3","imgcold4"],
"copyright" : ["FOR TEST ONLY", "FOR TEST ONLY", "FOR TEST ONLY","FOR TEST ONLY"]}],
"answer" : [
"COLD","FROID","FREDDO","FRÍO","KALT","FRIO"
]
},{
"img" : 
[{"file": ["imgviolet1","imgviolet2","imgviolet3","imgviolet4"],
"copyright" : ["FOR TEST ONLY", "FOR TEST ONLY", "FOR TEST ONLY","FOR TEST ONLY"]}],
"answer" : [
"VIOLET","VIOLET","VIOLA","VIOLETA","VEILCHEN","VIOLETA"
]
},{
"img" : 
[{"file": ["imgchord1","imgchord2","imgchord3","imgchord4"],
"copyright" : ["mytholipedia.com", "www.livescience.com", "123RF.com","joho.org"]}],
"answer" : [
"CORD","CORDON","CORDA","CUERDA","SEIL","CORDA"
]
},{
"img" : 
[{"file": ["imgcolors1","imgcolors2","imgcolors3","imgcolors4"],
"copyright" : ["huffingtonpost.it", "reporternuovo.it", "faidatemania.it","easyservicesolutions.com"]}],
"answer" : [
"COLORS","COULEURS","COLORI","COLORS","FARBE","COR"
]
},{
"img" : 
[{"file": ["imgrubber1","imgrubber2","imgrubber3","imgrubber4"],
"copyright" : ["huffingtonpost.it", "reporternuovo.it", "faidatemania.it","easyservicesolutions.com"]}],
"answer" : [
"RUBBER","GOMME","GOMMA","GOMA","GUMMI","BORRACHA"
]
},{
"img" : 
[{"file": ["imgdelete1","imgdelete2","imgdelete3","imgdelete4"],
"copyright" : ["static.trackback.it", "lospiffero.com", "medicservice.it","it.wikihow.com"]}],
"answer" : [
"DELETE","EFFACER","CANCELLA","ELIMINAR","STORNIEREN","REMOVER"
]
},{
"img" : 
[{"file": ["imgclimb1","imgclimb2","imgclimb3","imgclimb4"],
"copyright" : ["palermomania.it", "leitv.it", "it.wikipedia.org","skiforum.it"]}],
"answer" : [
"CLIMB","MONTÉE","SALITA","SUBIDA","AUFSTIEG","SUBIDA"
]
},{
"img" : 
[{"file": ["imgwine1","imgwine2","imgwine3","imgwine4"],
"copyright" : ["it.wikipedia.org", "en.wikipedia.org", "cdm-1.pianetagreen.it","immagini.4ever.eu"]}],
"answer" : [
"WINE","VIN","VINO","VINO","WEIN","VINHO"
]
},{
"img" : 
[{"file": ["imgorange1","imgorange2","imgorange3","imgorange4"],
"copyright" : ["freshplaza.it", "wallpaperart.org", "ilsanoquotidiano.com","2il.org"]}],
"answer" : [
"ORANGE","ORANGE","ARANCIO","NARANJA","ORANGE","LARANJA"
]
},{
"img" : 
[{"file": ["imgbed1","imgbed2","imgbed3","imgbed4"],
"copyright" : ["doghematerassi.it", "cosedicasa.com", "benessereblog.it","soluzionidicasa.com"]}],
"answer" : [
"BED","LIT","LETTO","CAMA","BETT","CAMA"
]
},{
"img" : 
[{"file": ["imgisland1","imgisland2","imgisland3","imgisland4"],
"copyright" : ["it.wikipedia.org", "sfondi-deskttop.eu", "it.freepik.com","tuttomaldive.it"]}],
"answer" : [
"ISLAND","ÎLE","ISOLA","ISLA","INSEL","ILHA"
]
},{
"img" : 
[{"file": ["imground1","imground2","imground3","imground4"],
"copyright" : ["codethislab", "lindiferenziato.com", "fmagazine.it","it.wikipedia.org"]}],
"answer" : [
"ROUND","ROND","ROTONDO","REDONDO","RUND","REDONDO"
]
},{
"img" : 
[{"file": ["imgiron1","imgiron2","imgiron3","imgiron4"],
"copyright" : ["FOR TEST ONLY", "FOR TEST ONLY", "FOR TEST ONLY","FOR TEST ONLY"]}],
"answer" : [
"IRON","FER","FERRO","HIERRO","EISEN","FERRO"
]
}
]