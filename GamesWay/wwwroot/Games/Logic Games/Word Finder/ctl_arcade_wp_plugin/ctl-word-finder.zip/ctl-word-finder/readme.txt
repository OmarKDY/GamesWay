=== CTL Word Finder ===
Tags: anagram, drag, multi language, word search, languages, letters, mobile, puzzle, ruzzle, skill, word, word game, multilanguage, kid game, school game, educational
Requires at least: 4.3
Tested up to: 4.3

Add Word Finder to CTL Arcade plugin

== Description ==
Add Word Finder to CTL Arcade plugin


	