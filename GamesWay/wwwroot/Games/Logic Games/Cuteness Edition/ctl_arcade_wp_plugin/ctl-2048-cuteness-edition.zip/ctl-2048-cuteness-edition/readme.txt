=== CTL 2048 Cuteness Edition ===
Tags: 2048, kid game, puzzle, puzzle game, skill game, math, brain game, board game, sudoku, number, pet, math game, html5 2048, html5 puzzle game, summer game
Requires at least: 4.3
Tested up to: 4.3

Add 2048 Cuteness Edition to CTL Arcade plugin

== Description ==
Add 2048 Cuteness Edition to CTL Arcade plugin


	