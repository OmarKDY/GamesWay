=== CTL Classic Nonogram ===
Tags: board game, brain game, brain teasers, crossword, grid, html5 board game, coloring game, math game, numbers, skill game, sudoku
Requires at least: 4.3
Tested up to: 4.3

Add Classic Nonogram to CTL Arcade plugin

== Description ==
Add Classic Nonogram to CTL Arcade plugin


	