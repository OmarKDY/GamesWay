=== CTL Battleship Minesweeper ===
Tags: canvas, html5, minesweeper, mobile, puzzle, strategy,windows game,field of flower,campo minato,démineur,buscaminas,campo minado,android, ios
Requires at least: 4.3
Tested up to: 4.3

Add Battleship Minesweeper to CTL Arcade plugin

== Description ==
Add Battleship Minesweeper to CTL Arcade plugin


	