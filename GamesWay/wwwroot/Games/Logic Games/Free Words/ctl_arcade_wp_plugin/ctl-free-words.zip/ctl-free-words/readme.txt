=== CTL Free Words ===
Tags: html5 word game, html5 puzzle, puzzle game, word game, kids game, ruzzle,  word game, anagrams, brain game, word html5 game, html5 solitaire, solitaire game, table game, strategy game, classic game
Requires at least: 4.3
Tested up to: 4.3

Add Free Words to CTL Arcade plugin

== Description ==
Add Free Words to CTL Arcade plugin


	